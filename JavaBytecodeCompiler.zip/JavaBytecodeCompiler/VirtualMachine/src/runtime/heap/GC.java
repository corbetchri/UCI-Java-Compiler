package runtime.heap;

import java.util.ArrayList;
import java.util.List;

import runtime.CallStack;
import runtime.descriptors.ArrayDescriptor;
import runtime.descriptors.ClassDescriptor;
import runtime.descriptors.TypeDescriptor;

public class GC {
    private final Heap heap;
    private final FreeList freeList;
    private final CallStack stack;

    public GC(Heap heap, FreeList freeList, CallStack stack) {
        this.heap = heap;
        this.freeList = freeList;
        this.stack = stack;
    }

    public void collect() {
        mark();
        sweep();
    }

    private void mark() {
        for (var root : getRootSet(stack)) {
            traverse(root);
        }
    }

    private void traverse(Pointer current) {
        if (current == null) {
            throw new AssertionError();
        }
        var block = heap.getAddress(current) - Heap.BLOCK_HEADER_SIZE;
        if (isMarked(block)) {
            return;
        }
        setMark(block);
        for (var next : getPointers(current)) {
            traverse(next);
        }
    }

    private Iterable<Pointer> getPointers(Pointer current) {
        var list = new ArrayList<Pointer>();
        var descriptor = heap.getDescriptor(current);
        if (descriptor instanceof ClassDescriptor) {
            var fields = ((ClassDescriptor) descriptor).getAllFields();
            for (var index = 0; index < fields.length; index++) {
                if (isPointerType(fields[index].getType())) {
                    var value = heap.readField(current, index);
                    if (value != null) {
                        list.add((Pointer) value);
                    }
                }
            }
        } else {
            var elementType = ((ArrayDescriptor) descriptor).getElementType();
            if (isPointerType(elementType)) {
                var length = heap.getArrayLength(current);
                for (var index = 0; index < length; index++) {
                    var value = heap.readElement(current, index);
                    if (value != null) {
                        list.add((Pointer) value);
                    }
                }
            }
        }
        return list;
    }

    private Iterable<Pointer> getRootSet(CallStack callStack) {
        var list = new ArrayList<Pointer>();
        for (var frame : callStack) {
            collectPointers(frame.getParameters(), list);
            collectPointers(frame.getLocals(), list);
            collectPointers(frame.getEvaluationStack().toArray(), list);
            list.add(frame.getThisReference());
        }
        return list;
    }

    private void collectPointers(Object[] values, List<Pointer> list) {
        for (var value : values) {
            if (value instanceof Pointer) {
                list.add((Pointer) value);
            }
        }
    }

    private boolean isPointerType(TypeDescriptor descriptor) {
        return descriptor instanceof ClassDescriptor || descriptor instanceof ArrayDescriptor;
    }

    private void sweep() {
        if (!isMarked(Heap.HEAP_START)) {
            freeList.add(Heap.HEAP_START);
        }
        clearMark(Heap.HEAP_START);
        var previous = Heap.HEAP_START;
        var current = Heap.HEAP_START + heap.getBlockSize(Heap.HEAP_START);
        while (current < Heap.HEAP_END) {
            if (isMarked(current)) {
                previous = current;
            } else if (freeList.isFree(previous)) { // merge
                heap.setBlockSize(previous, heap.getBlockSize(previous) + heap.getBlockSize(current));
            } else { // free
                if (!freeList.isFree(current)) {
                    freeList.add(current);
                }
                previous = current;
            }
            clearMark(current);
            current = previous + heap.getBlockSize(previous);
        }
    }

    private void setMark(long block) {
        heap.writeLong64(block, heap.readLong64(block) | 0x8000000000000000L);
    }

    private void clearMark(long block) {
        heap.writeLong64(block, heap.readLong64(block) & 0x7fffffffffffffffL);
    }

    private boolean isMarked(long block) {
        return (heap.readLong64(block) & 0x8000000000000000L) != 0;
    }
}
