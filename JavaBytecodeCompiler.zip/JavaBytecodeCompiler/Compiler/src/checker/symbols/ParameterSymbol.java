package checker.symbols;

public class ParameterSymbol extends VariableSymbol {
	public ParameterSymbol(Symbol scope, String identifier) {
		super(scope, identifier);	
	}	
}
