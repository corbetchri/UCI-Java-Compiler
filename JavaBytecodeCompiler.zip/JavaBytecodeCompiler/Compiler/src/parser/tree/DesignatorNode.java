package parser.tree;

import common.Location;

public abstract class DesignatorNode extends ExpressionNode {
	public DesignatorNode(Location location) {
		super(location);
	}
}
