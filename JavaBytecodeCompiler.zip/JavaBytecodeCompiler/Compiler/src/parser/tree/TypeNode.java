package parser.tree;

import common.Location;

public abstract class TypeNode extends Node {
	public TypeNode(Location location) {
		super(location);
	}	
}
