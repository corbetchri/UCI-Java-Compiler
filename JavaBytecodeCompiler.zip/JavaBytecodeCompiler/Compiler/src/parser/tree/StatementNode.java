package parser.tree;

import common.Location;

public abstract class StatementNode extends Node {
	public StatementNode(Location location) {
		super(location);
	}
}
