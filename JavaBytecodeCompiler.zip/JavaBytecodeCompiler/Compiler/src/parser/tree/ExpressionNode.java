package parser.tree;

import common.Location;

public abstract class ExpressionNode extends Node {
	public ExpressionNode(Location location) {
		super(location);
	}
}
