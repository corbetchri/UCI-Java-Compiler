package checker.symbols;

public class FieldSymbol extends VariableSymbol {
	public FieldSymbol(Symbol scope, String identifier) {
		super(scope, identifier);
	}
}
