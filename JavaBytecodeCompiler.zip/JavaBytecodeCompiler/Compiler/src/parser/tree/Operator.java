package parser.tree;

public enum Operator {
	AND,
    DIVIDE,
    EQUAL, UNEQUAL,
    INSTANCEOF,
    GREATER, GREATER_EQUAL,
    MINUS,
    MODULO,
    NOT,
    OR,
    PLUS,
    LESS, LESS_EQUAL,
    TIMES,
}
